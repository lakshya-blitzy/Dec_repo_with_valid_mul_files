"""Pytest-based API test module for Flask API endpoints.

Tests HTTP GET, POST, PUT, DELETE operations on API routes, verifying
correct response status codes, JSON response formats, and data handling.
Uses pytest fixtures from conftest.py for test client setup.

This file replaces Jest/Mocha test files from Node.js with pytest equivalents
per Section 0.7.6 conversion requirement.
"""

import pytest
from app import app


class TestAppConfiguration:
    """Tests for Flask application configuration."""

    def test_app_config_is_accessible(self):
        """Verify app.config can be accessed for testing configuration."""
        assert app.config is not None
        assert 'TESTING' in app.config or 'DEBUG' in app.config

    def test_test_client_creates_client(self):
        """Verify app.test_client() creates a functional test client."""
        client = app.test_client()
        assert client is not None


class TestHealthEndpoint:
    """Tests for GET /api/health endpoint."""

    def test_health_check(self, client):
        """Test health endpoint returns 200 with healthy status."""
        response = client.get('/api/health')
        assert response.status_code == 200
        assert response.json['status'] == 'healthy'


class TestGetItemsEndpoint:
    """Tests for GET /api/items endpoint."""

    def test_get_items(self, client):
        """Test list items returns 200 with array response."""
        response = client.get('/api/items')
        assert response.status_code == 200
        assert isinstance(response.json, list)

    def test_get_items_returns_empty_initially(self, client):
        """Test list items returns empty array when no items exist."""
        response = client.get('/api/items')
        assert response.json == []


class TestGetItemByIdEndpoint:
    """Tests for GET /api/items/<id> endpoint."""

    def test_get_item_by_id_not_found(self, client):
        """Test get item returns 404 for non-existent item."""
        response = client.get('/api/items/999')
        assert response.status_code == 404
        assert 'error' in response.json

    def test_get_item_by_id_after_create(self, client, auth_headers):
        """Test get item returns item after creation."""
        create_resp = client.post(
            '/api/items',
            json={'email': 'test@example.com', 'password': 'pass123'},
            headers=auth_headers
        )
        item_id = create_resp.json['id']
        response = client.get(f'/api/items/{item_id}')
        assert response.status_code == 200
        assert response.json['id'] == item_id


class TestCreateItemEndpoint:
    """Tests for POST /api/items endpoint."""

    def test_create_item_requires_auth(self, client):
        """Test create item returns 401 without authentication."""
        response = client.post('/api/items', json={'email': 'test@example.com', 'password': 'pass'})
        assert response.status_code == 401

    def test_create_item_requires_body(self, client, auth_headers):
        """Test create item returns 400 without request body."""
        response = client.post('/api/items', headers=auth_headers, content_type='application/json')
        assert response.status_code == 400

    def test_create_item(self, client, auth_headers):
        """Test create item returns 201 with created item data."""
        response = client.post(
            '/api/items',
            json={'email': 'new@example.com', 'password': 'password123'},
            headers=auth_headers
        )
        assert response.status_code == 201
        assert 'id' in response.json
        assert response.json['email'] == 'new@example.com'

    def test_create_item_validates_required_fields(self, client, auth_headers):
        """Test create item returns 400 for invalid data."""
        response = client.post(
            '/api/items',
            json={'email': '', 'password': ''},
            headers=auth_headers
        )
        assert response.status_code == 400


class TestUpdateItemEndpoint:
    """Tests for PUT /api/items/<id> endpoint."""

    def test_update_item_requires_auth(self, client):
        """Test update item returns 401 without authentication."""
        response = client.put('/api/items/1', json={'email': 'new@example.com'})
        assert response.status_code == 401

    def test_update_item_not_found(self, client, auth_headers):
        """Test update item returns 404 for non-existent item."""
        response = client.put(
            '/api/items/999',
            json={'email': 'new@example.com'},
            headers=auth_headers
        )
        assert response.status_code == 404

    def test_update_item(self, client, auth_headers):
        """Test update item returns 200 with updated data."""
        create_resp = client.post(
            '/api/items',
            json={'email': 'original@example.com', 'password': 'pass123'},
            headers=auth_headers
        )
        item_id = create_resp.json['id']
        response = client.put(
            f'/api/items/{item_id}',
            json={'email': 'updated@example.com'},
            headers=auth_headers
        )
        assert response.status_code == 200
        assert response.json['email'] == 'updated@example.com'


class TestDeleteItemEndpoint:
    """Tests for DELETE /api/items/<id> endpoint."""

    def test_delete_item_requires_auth(self, client):
        """Test delete item returns 401 without authentication."""
        response = client.delete('/api/items/1')
        assert response.status_code == 401

    def test_delete_item_not_found(self, client, auth_headers):
        """Test delete item returns 404 for non-existent item."""
        response = client.delete('/api/items/999', headers=auth_headers)
        assert response.status_code == 404

    def test_delete_item(self, client, auth_headers):
        """Test delete item returns 200 on successful deletion."""
        create_resp = client.post(
            '/api/items',
            json={'email': 'delete@example.com', 'password': 'pass123'},
            headers=auth_headers
        )
        item_id = create_resp.json['id']
        response = client.delete(f'/api/items/{item_id}', headers=auth_headers)
        assert response.status_code == 200
        verify_resp = client.get(f'/api/items/{item_id}')
        assert verify_resp.status_code == 404


@pytest.mark.integration
class TestCRUDWorkflow:
    """Integration tests for complete CRUD workflow."""

    def test_full_crud_workflow(self, client, auth_headers):
        """Test complete create, read, update, delete cycle."""
        # Create
        create_resp = client.post(
            '/api/items',
            json={'email': 'crud@example.com', 'password': 'password123'},
            headers=auth_headers
        )
        assert create_resp.status_code == 201
        item_id = create_resp.json['id']

        # Read
        get_resp = client.get(f'/api/items/{item_id}')
        assert get_resp.status_code == 200
        assert get_resp.json['email'] == 'crud@example.com'

        # Update
        update_resp = client.put(
            f'/api/items/{item_id}',
            json={'email': 'updated@example.com'},
            headers=auth_headers
        )
        assert update_resp.status_code == 200
        assert update_resp.json['email'] == 'updated@example.com'

        # Delete
        delete_resp = client.delete(f'/api/items/{item_id}', headers=auth_headers)
        assert delete_resp.status_code == 200

        # Verify deleted
        verify_resp = client.get(f'/api/items/{item_id}')
        assert verify_resp.status_code == 404


@pytest.mark.error_handling
class TestErrorResponses:
    """Tests for error handling and edge cases."""

    def test_404_json_format(self, client):
        """Test 404 responses return proper JSON format."""
        response = client.get('/api/items/999')
        assert response.status_code == 404
        assert 'error' in response.json

    def test_401_json_format(self, client):
        """Test 401 responses return proper JSON format."""
        response = client.post('/api/items', json={'test': 'data'})
        assert response.status_code == 401
        assert 'error' in response.json

    def test_invalid_json_body(self, client, auth_headers):
        """Test invalid JSON body returns 400."""
        response = client.post(
            '/api/items',
            data='not json',
            headers=auth_headers,
            content_type='application/json'
        )
        assert response.status_code == 400
