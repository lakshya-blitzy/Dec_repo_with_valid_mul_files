"""Pytest configuration and fixtures for Flask application test suite.

This module provides shared test setup including Flask test client,
application context, and database fixtures. Central configuration point
for pytest settings and test environment setup.

The fixtures follow pytest patterns that replace Jest/Mocha beforeEach/afterEach
and describe blocks with Python's fixture-based dependency injection.

Usage:
    def test_example(client):
        response = client.get('/api/health')
        assert response.status_code == 200

Exports:
    app: Flask application fixture configured for testing
    client: Flask test client fixture for making HTTP requests
"""

import pytest

from app import create_app
from models import db


def pytest_configure(config):
    """Register custom pytest markers to avoid warnings.
    
    Registers the custom markers used in test_api.py:
    - integration: marks tests as integration tests
    - error_handling: marks tests as error handling tests
    """
    config.addinivalue_line("markers", "integration: marks tests as integration tests")
    config.addinivalue_line("markers", "error_handling: marks tests as error handling tests")


@pytest.fixture(scope='function')
def app():
    """Create Flask application instance configured for testing.
    
    Creates a fresh Flask app instance with TestingConfig for each test
    function, ensuring complete test isolation. Sets up the database
    tables before tests and tears them down afterward.
    
    The fixture provides access to app.config and app.test_client() as
    specified in the exports schema.
    
    Yields:
        Flask: Application instance with TESTING=True, in-memory SQLite
               database, and disabled CSRF protection.
    
    Example:
        def test_app_config(app):
            assert app.config['TESTING'] is True
            assert 'sqlite' in app.config['SQLALCHEMY_DATABASE_URI']
    """
    flask_app = create_app('testing')
    
    with flask_app.app_context():
        db.create_all()
        yield flask_app
        db.drop_all()


@pytest.fixture(scope='function')
def client(app):
    """Create Flask test client for making HTTP requests.
    
    Provides a test client that can make GET, POST, PUT, DELETE, and PATCH
    requests to the Flask application without running an actual server.
    
    The test client automatically handles application context and request
    context management.
    
    Args:
        app: Flask application fixture (automatically injected by pytest).
    
    Returns:
        FlaskClient: Test client instance with methods for HTTP requests:
            - get(path, **kwargs): Make GET request
            - post(path, **kwargs): Make POST request  
            - put(path, **kwargs): Make PUT request
            - delete(path, **kwargs): Make DELETE request
            - patch(path, **kwargs): Make PATCH request
    
    Example:
        def test_health_endpoint(client):
            response = client.get('/api/health')
            assert response.status_code == 200
            
        def test_create_resource(client):
            response = client.post('/api/users', 
                                   json={'name': 'test'},
                                   content_type='application/json')
            assert response.status_code == 201
    """
    return app.test_client()


@pytest.fixture(scope='function')
def auth_headers():
    """Create authentication headers for protected route testing.
    
    Provides a dictionary with Authorization header for tests that require
    authentication. This fixture works with the require_auth middleware
    decorator which validates the presence of an Authorization header.
    
    Returns:
        dict: Headers dictionary containing Authorization bearer token.
    
    Example:
        def test_protected_endpoint(client, auth_headers):
            response = client.post('/api/items', 
                                   json={'data': 'test'},
                                   headers=auth_headers)
            assert response.status_code == 201
    """
    return {'Authorization': 'Bearer test-token'}
