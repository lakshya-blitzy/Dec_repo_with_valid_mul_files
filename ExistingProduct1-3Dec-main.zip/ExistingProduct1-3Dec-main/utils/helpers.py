"""General-purpose utility functions for the Flask application.

Provides common utilities for data formatting, response helpers, string manipulation,
date handling, and other reusable functionality. Functions are designed to be stateless
and pure for testability.
"""

from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional, Tuple, Union
import re


def format_response(
    data: Any = None,
    message: str = "Success",
    success: bool = True,
    **extra: Any
) -> Dict[str, Any]:
    """Format a standardized API response dictionary.
    
    Args:
        data: The response payload data.
        message: Human-readable message describing the response.
        success: Whether the operation was successful.
        **extra: Additional fields to include in the response.
    
    Returns:
        Dictionary with standardized response structure.
    """
    response = {"success": success, "message": message}
    if data is not None:
        response["data"] = data
    return {**response, **extra}


def format_error(
    message: str,
    code: Optional[str] = None,
    details: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """Format a standardized error response dictionary.
    
    Args:
        message: Human-readable error message.
        code: Optional error code for programmatic handling.
        details: Optional additional error details.
    
    Returns:
        Dictionary with standardized error structure.
    """
    error: Dict[str, Any] = {"success": False, "error": {"message": message}}
    if code:
        error["error"]["code"] = code
    if details:
        error["error"]["details"] = details
    return error


def format_datetime(
    dt: Optional[datetime] = None,
    fmt: str = "%Y-%m-%dT%H:%M:%SZ"
) -> str:
    """Format a datetime object to a string.
    
    Args:
        dt: Datetime object to format. Defaults to current UTC time.
        fmt: strftime format string. Defaults to ISO 8601 format.
    
    Returns:
        Formatted datetime string.
    """
    return (dt or datetime.now(timezone.utc).replace(tzinfo=None)).strftime(fmt)


def parse_datetime(
    date_string: str,
    fmt: Optional[str] = None
) -> Optional[datetime]:
    """Parse a datetime string to a datetime object.
    
    Args:
        date_string: String to parse.
        fmt: Optional strftime format. If None, tries ISO format first.
    
    Returns:
        Parsed datetime object, or None if parsing fails.
    """
    if not date_string:
        return None
    try:
        if fmt:
            return datetime.strptime(date_string, fmt)
        return datetime.fromisoformat(date_string.replace("Z", "+00:00"))
    except (ValueError, AttributeError):
        return None


def get_current_timestamp(utc: bool = True) -> datetime:
    """Get the current timestamp.
    
    Args:
        utc: If True, return UTC time. Otherwise, return local time.
    
    Returns:
        Current datetime object (timezone-naive for compatibility).
    """
    if utc:
        return datetime.now(timezone.utc).replace(tzinfo=None)
    return datetime.now()


# Pre-compiled regex patterns for performance
_SLUGIFY_PATTERN = re.compile(r"[^\w\s-]")
_WHITESPACE_PATTERN = re.compile(r"[-\s]+")
_SANITIZE_PATTERN = re.compile(r"[<>&\"']")


def slugify(text: str, separator: str = "-") -> str:
    """Convert text to URL-friendly slug.
    
    Args:
        text: Input text to slugify.
        separator: Character to use between words. Defaults to hyphen.
    
    Returns:
        Slugified lowercase string.
    """
    if not text:
        return ""
    text = _SLUGIFY_PATTERN.sub("", text.lower().strip())
    return _WHITESPACE_PATTERN.sub(separator, text).strip(separator)


def sanitize_string(
    text: str,
    replacement: str = ""
) -> str:
    """Sanitize a string by removing potentially dangerous characters.
    
    Removes HTML-sensitive characters: < > & " '
    
    Args:
        text: Input string to sanitize.
        replacement: String to replace dangerous characters with.
    
    Returns:
        Sanitized string.
    """
    if not text:
        return ""
    return _SANITIZE_PATTERN.sub(replacement, text)


def safe_get(
    data: Union[Dict[str, Any], List[Any], None],
    key: Union[str, int],
    default: Any = None
) -> Any:
    """Safely get a value from a dictionary or list.
    
    Args:
        data: Dictionary or list to access.
        key: Key (for dict) or index (for list) to retrieve.
        default: Default value if key doesn't exist or data is None.
    
    Returns:
        The value at the key/index, or the default value.
    """
    if data is None:
        return default
    try:
        return data[key]
    except (KeyError, IndexError, TypeError):
        return default


def paginate(
    items: List[Any],
    page: int = 1,
    per_page: int = 10
) -> Tuple[List[Any], Dict[str, Any]]:
    """Paginate a list of items.
    
    Args:
        items: List of items to paginate.
        page: Current page number (1-indexed).
        per_page: Number of items per page.
    
    Returns:
        Tuple of (paginated items, pagination metadata dict).
    """
    page = max(1, page)
    per_page = max(1, min(100, per_page))
    total = len(items)
    total_pages = (total + per_page - 1) // per_page or 1
    start = (page - 1) * per_page
    
    return items[start:start + per_page], {
        "page": page,
        "per_page": per_page,
        "total": total,
        "total_pages": total_pages,
        "has_next": page < total_pages,
        "has_prev": page > 1
    }
