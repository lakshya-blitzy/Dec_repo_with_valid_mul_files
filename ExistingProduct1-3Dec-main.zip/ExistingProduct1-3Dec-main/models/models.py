"""
SQLAlchemy data model definitions for the Flask application.

This module contains all database model classes that inherit from db.Model.
Models define table structures, column specifications, and relationships,
serving as the data layer for the application.

The User model follows the Mongoose to SQLAlchemy transformation pattern
from Section 0.4.7 of the migration plan.
"""
from datetime import datetime, timezone
from models import db


def _utc_now():
    """Get current UTC time as timezone-naive datetime for database storage."""
    return datetime.now(timezone.utc).replace(tzinfo=None)


class User(db.Model):
    """
    User model representing the users table in the database.
    
    Equivalent to the Mongoose User schema from the original Node.js application.
    Provides user authentication data storage with email/password fields.
    
    Attributes:
        id: Primary key auto-incrementing integer
        email: Unique email address (required)
        password: Hashed password string (required)
        created_at: Timestamp of user creation (defaults to current UTC time)
    """
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime, default=_utc_now)
    
    def to_dict(self):
        """
        Convert model instance to dictionary for JSON serialization.
        
        Used with Flask's jsonify() to return user data in API responses.
        Excludes password field for security.
        
        Returns:
            dict: Dictionary containing id, email, and created_at fields
        """
        return {
            'id': self.id,
            'email': self.email,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }
    
    def __repr__(self):
        """String representation of User instance for debugging."""
        return f'<User {self.email}>'
