"""
Models package initialization module.

This module creates and exports the SQLAlchemy database instance (db) used
across the Flask application for all database operations, model definitions,
and query execution. The db instance supports the application factory pattern
where db.init_app(app) is called in app.py.

Exports:
    db: SQLAlchemy instance providing:
        - Model: Base class for all models
        - Column, Integer, String, DateTime, Text, Boolean, Float: Column types
        - ForeignKey, relationship, backref: Relationship definitions
        - session: Database session for queries
        - create_all(), drop_all(): Table management
        - init_app(): Flask application initialization
    User: User model class for authentication data storage
"""
from flask_sqlalchemy import SQLAlchemy

# Central SQLAlchemy database instance shared across the application.
# Initialize with Flask app using db.init_app(app) in the application factory.
db = SQLAlchemy()


def _import_models():
    """Import models after db is defined to avoid circular imports."""
    from models.models import User
    return User


# Lazy import of User model - use after db.init_app(app) is called
# This is a function to enable importing models after app context is available
# Usage: from models import db, User (within app context)
def __getattr__(name):
    """Enable lazy imports of model classes to avoid circular import issues."""
    if name == 'User':
        from models.models import User
        return User
    raise AttributeError(f"module 'models' has no attribute '{name}'")


# Export db for convenient package-level access: from models import db, User
__all__ = ['db', 'User']
