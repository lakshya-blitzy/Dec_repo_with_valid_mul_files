"""Package initialization and Blueprint registration module for the routes directory.

Imports the api_bp Blueprint from api.py and exports it for registration
in the main Flask application (app.py). Provides a clean package interface
enabling 'from routes import api_bp' pattern.

The exported blueprint is registered in app.py using:
    app.register_blueprint(api_bp, url_prefix='/api')

Exports:
    api_bp: Flask Blueprint instance containing all API route handlers
"""

from .api import api_bp

__all__ = ['api_bp']
