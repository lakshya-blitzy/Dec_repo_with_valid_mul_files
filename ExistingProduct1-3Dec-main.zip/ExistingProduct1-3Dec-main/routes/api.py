"""Flask Blueprint module containing all API route handlers.

Defines HTTP endpoints using @blueprint.route decorators for GET, POST, PUT,
DELETE methods. This is the Python/Flask equivalent of Express.js route files,
converting Express handlers to Flask Blueprint route decorators.

Route handlers use Flask's request object for input (request.json, request.args)
and jsonify() for JSON responses.

Exports:
    api_bp: Flask Blueprint instance for API routes
"""

from flask import Blueprint, request, jsonify
from services import get_all, get_by_id, create, update, delete
from middleware import require_auth

api_bp = Blueprint('api', __name__)


@api_bp.route('/health')
def health_check():
    """Health check endpoint for monitoring and load balancer probes."""
    return jsonify({'status': 'healthy'})


@api_bp.route('/items')
def list_items():
    """GET /items - Retrieve all items."""
    return jsonify(get_all())


@api_bp.route('/items/<int:item_id>')
def get_item(item_id):
    """GET /items/<id> - Retrieve a single item by ID."""
    item = get_by_id(item_id)
    if not item:
        return jsonify({'error': 'Item not found'}), 404
    return jsonify(item)


@api_bp.route('/items', methods=['POST'])
@require_auth
def create_item():
    """POST /items - Create a new item. Requires authentication."""
    try:
        data = request.get_json(force=True, silent=True)
    except Exception:
        data = None
    if not data:
        return jsonify({'error': 'Request body is required'}), 400
    try:
        item = create(data)
        return jsonify(item), 201
    except ValueError as e:
        return jsonify({'error': str(e)}), 400


@api_bp.route('/items/<int:item_id>', methods=['PUT'])
@require_auth
def update_item(item_id):
    """PUT /items/<id> - Update an existing item. Requires authentication."""
    try:
        data = request.get_json(force=True, silent=True)
    except Exception:
        data = None
    if not data:
        return jsonify({'error': 'Request body is required'}), 400
    item = update(item_id, data)
    if not item:
        return jsonify({'error': 'Item not found'}), 404
    return jsonify(item)


@api_bp.route('/items/<int:item_id>', methods=['DELETE'])
@require_auth
def delete_item(item_id):
    """DELETE /items/<id> - Delete an item. Requires authentication."""
    if delete(item_id):
        return jsonify({'message': 'Item deleted'}), 200
    return jsonify({'error': 'Item not found'}), 404
