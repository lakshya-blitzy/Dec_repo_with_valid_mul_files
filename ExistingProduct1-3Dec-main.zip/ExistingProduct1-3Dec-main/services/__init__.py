"""
Services package initialization module.

Exports service functions for convenient package-level access throughout
the Flask application. Enables 'from services import get_all' pattern
rather than 'from services.services import get_all'.

Exports:
    get_all: Retrieve all users from the database
    get_by_id: Retrieve a single user by ID
    create: Create a new user with provided data
    update: Update an existing user by ID
    delete: Delete a user by ID
"""
from services.services import get_all, get_by_id, create, update, delete

__all__ = ['get_all', 'get_by_id', 'create', 'update', 'delete']
