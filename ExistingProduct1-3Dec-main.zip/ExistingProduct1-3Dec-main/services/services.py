"""
Business logic service module implementing the service layer pattern.

This module provides stateless CRUD service functions that encapsulate
business logic for interacting with database models. Services handle data
processing, validation, and model operations while routes handle HTTP concerns.

Follows Flask/Python migration patterns from Node.js controllers, using
Pythonic patterns for minimal code with maximum readability.

Exports:
    get_all: Retrieve all users from the database
    get_by_id: Retrieve a single user by ID
    create: Create a new user with provided data
    update: Update an existing user by ID
    delete: Delete a user by ID
"""
from typing import Any, Dict, List, Optional

from models import db
from models.models import User


def get_all() -> List[Dict[str, Any]]:
    """
    Retrieve all users from the database.
    
    Returns:
        List of user dictionaries with id, email, and created_at fields.
        Returns empty list if no users exist.
    """
    return [user.to_dict() for user in User.query.all()]


def get_by_id(user_id: int) -> Optional[Dict[str, Any]]:
    """
    Retrieve a single user by their ID.
    
    Args:
        user_id: The unique identifier of the user to retrieve.
    
    Returns:
        User dictionary if found, None if user does not exist.
    """
    user = db.session.get(User, user_id)
    return user.to_dict() if user else None


def create(data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Create a new user with the provided data.
    
    Args:
        data: Dictionary containing user data with required keys:
            - email (str): User's email address
            - password (str): User's password (should be pre-hashed)
    
    Returns:
        Dictionary representation of the created user.
    
    Raises:
        ValueError: If required fields are missing from data.
        IntegrityError: If email already exists (unique constraint violation).
    """
    if not data.get('email') or not data.get('password'):
        raise ValueError("Email and password are required")
    
    user = User(email=data['email'], password=data['password'])
    db.session.add(user)
    db.session.commit()
    return user.to_dict()


def update(user_id: int, data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """
    Update an existing user with the provided data.
    
    Args:
        user_id: The unique identifier of the user to update.
        data: Dictionary containing fields to update (email, password).
    
    Returns:
        Updated user dictionary if found and updated, None if user not found.
    """
    user = db.session.get(User, user_id)
    if not user:
        return None
    
    if 'email' in data:
        user.email = data['email']
    if 'password' in data:
        user.password = data['password']
    
    db.session.commit()
    return user.to_dict()


def delete(user_id: int) -> bool:
    """
    Delete a user by their ID.
    
    Args:
        user_id: The unique identifier of the user to delete.
    
    Returns:
        True if user was found and deleted, False if user did not exist.
    """
    user = db.session.get(User, user_id)
    if not user:
        return False
    
    db.session.delete(user)
    db.session.commit()
    return True


def get_by_email(email: str) -> Optional[Dict[str, Any]]:
    """
    Retrieve a user by their email address.
    
    Args:
        email: The email address to search for.
    
    Returns:
        User dictionary if found, None if no user with that email exists.
    """
    user = User.query.filter_by(email=email).first()
    return user.to_dict() if user else None
