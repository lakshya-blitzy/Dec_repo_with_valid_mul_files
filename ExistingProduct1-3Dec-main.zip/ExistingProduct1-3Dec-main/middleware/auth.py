"""Authentication middleware module for Flask route protection.

This module provides the require_auth decorator that validates Authorization
headers on protected routes, converting the Express.js middleware pattern
to a Pythonic Flask decorator pattern.
"""

from functools import wraps
from flask import request, jsonify


def require_auth(f):
    """Decorator that requires valid Authorization header for protected routes.
    
    Checks for the presence of an Authorization header in the request.
    Returns 401 Unauthorized if the header is missing or empty.
    
    Args:
        f: The Flask route function to protect.
        
    Returns:
        The decorated function that validates authentication before execution.
        
    Example:
        @app.route('/api/protected')
        @require_auth
        def protected_route():
            return jsonify({'data': 'secret'})
    """
    @wraps(f)
    def decorated(*args, **kwargs):
        auth_header = request.headers.get('Authorization')
        if not auth_header:
            return jsonify({'error': 'Unauthorized'}), 401
        return f(*args, **kwargs)
    return decorated
