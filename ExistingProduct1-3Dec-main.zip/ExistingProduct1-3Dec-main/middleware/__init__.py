"""Middleware package providing route protection decorators.

Exports the require_auth decorator for convenient package-level imports.
"""

from middleware.auth import require_auth

__all__ = ['require_auth']
